package com.labs.spring.boot.helloworldspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
